export WM_SCHEDULER=ccache
export CCACHE_DIR=/vagrant/ccache4vm
