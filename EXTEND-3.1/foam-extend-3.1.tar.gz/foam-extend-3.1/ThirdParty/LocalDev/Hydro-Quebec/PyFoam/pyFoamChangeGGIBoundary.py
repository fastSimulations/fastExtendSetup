#!/usr/bin/env python

from PyFoam.Applications.ChangeGGIBoundary import ChangeGGIBoundary

ChangeGGIBoundary()
