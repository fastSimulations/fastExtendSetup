#!/usr/bin/env python

from PyFoam.Applications.InitMixingPlaneInterface import InitMixingPlaneInterface

InitMixingPlaneInterface()
