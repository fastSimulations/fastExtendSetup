#!/usr/bin/env python

from PyFoam.Applications.ChangeMixingPlaneBoundary import ChangeMixingPlaneBoundary

ChangeMixingPlaneBoundary()
