#!/usr/bin/env python

from PyFoam.Applications.InitGgiInterface import InitGgiInterface

InitGgiInterface()
