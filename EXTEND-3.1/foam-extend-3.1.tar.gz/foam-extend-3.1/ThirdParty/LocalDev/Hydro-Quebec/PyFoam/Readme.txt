PyFoam scripts for handling GGI and mixingPlane cases.

--
Martin Beaudoin
Hydro-Quebec
April 2012
