This directory contains ThirdParty developments specific to the mixingPlane_RC1 branch.
Those developments might eventually find a more suitable home elsewhere.

Instead of spreading these developments around in various repositories, I find 
it more convenient to regroup them under this directory.

So expect this ThirdParty/LocalDev directory to disappear eventually, once its
content will prove it usefulness.

--
Martin Beaudoin
Hydro-Quebec
April 2012
