15/8/8 Simple T-junction. Inlet on left, one outlet at bottom, one at top.
To test multiple outlets.
