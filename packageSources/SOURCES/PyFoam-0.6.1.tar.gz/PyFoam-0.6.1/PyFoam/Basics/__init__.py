#  ICE Revision: $Id$ 
""" Helper-Classes

These Classes didn't fit anywhere else
"""
